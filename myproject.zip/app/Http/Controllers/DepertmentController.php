<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Depertment;
use App\Teacher;

class DepertmentController extends Controller
{
    public function index()
    {
        $depertments = Depertment::all();
        return view('home',compact('depertments'));
    }
    
    public function getTeachers(Request $request, $id)
    {
        if($request->ajax()){
            $teachers = Teacher::teachers($id);
            return response()->json($teachers);
        }
    }
}
