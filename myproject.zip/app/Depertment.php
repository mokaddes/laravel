<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Depertment extends Model
{
    protected $table = 'depertments';
    protected $fillable = ['name'];
}
