<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
<!--
                    <?php echo Form::select('depertment',$depertments, null,['id'=>'depertment','class'=>'dept']); ?>

                    <br>
                    <?php echo Form::select('teachers',['placeholder'=>'Select Teacher'],null,['id'=>'teacher','class'=>'tcr']); ?>

-->
                    
                    <form action="">
                       
                       <?php echo e(csrf_field()); ?>

                        <div class="form-group">

                        <label for="">Depertment</label>

                        <select name="depertment" id="depertment" class="form-control input-sm depertment">
                            
                             <?php $__currentLoopData = $depertments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $depertment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                              <option value="<?php echo e($depertment->id); ?>"><?php echo e($depertment->name); ?></option>
                            
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                        </select>

                        <label for="">Teacher</label>
                        <select name="teacher" id="teacher" class="form-control input-sm">
                            <option value=""></option>
                        </select>
                    </form>
                    
                
        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('script'); ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script type="text/javascript">
    $(document).ready(function() {
        $("#depertment").change(function() {
            console.log($("#depertment").val());
            $.getJSON("/home/teacher/" + $("#depertment").val(), function(data) {
                var $teachers = $("#teacher");
                $teachers.empty();
                $.each(data, function(id, name) {
                    $teachers.append('<option value="' + id +'">' + name + '</option>');
                });
                $("#teacher").trigger("change"); /* trigger next drop down list not in the example */
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>